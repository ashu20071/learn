/*
package GeekTrust.TameOfThrones;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeektrustTest {

    DecipherMessage decipherMessage = new DecipherMessage();

    @Test
    public void decipherTest() {

    }
}
*/
